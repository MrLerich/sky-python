
from function import load_question, get_statistics
from classes import Question

print('Игра начинается')

games = len(load_question())

point = 0
correct_answers = 0
for question in load_question():
    s = Question(question['q'], question['d'], question['a'])
    print(s.build_question())
    user_type_answer = input('Введите ответ: ')
    if s.is_correct(user_type_answer):
        correct_answers += 1
        point += s.get_points()
        print(s.build_positive_feedback())
    else:
        print(s.build_negative_feedback())

print(get_statistics(point, correct_answers))
